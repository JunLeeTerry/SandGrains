package jtf.tutorial.textfolding;

import jtf.tutorial.grammar.TokenList;
import jtf.tutorial.grammar.TokenManager;
import jtf.tutorial.ui.ExprViewer;

import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.reconciler.DirtyRegion;
import org.eclipse.jface.text.reconciler.IReconcilingStrategy;

public class ExprReconcilingStrategy implements IReconcilingStrategy {
	private IDocument doc;
	private ExprViewer viewer;
	
	public ExprReconcilingStrategy(ExprViewer viewer) {
		this.viewer = viewer;
	}
	
	private void internalReconcile() {
		TokenList list = TokenManager.getTokenList(doc);
		viewer.updateProjectionAnnotations(list.getLineRanges());
	}

	public void reconcile(IRegion partition) {
		internalReconcile();
	}

	public void reconcile(DirtyRegion dirtyRegion, IRegion subRegion) {
		internalReconcile();
	}

	public void setDocument(IDocument document) {
		doc = document;
	}
}
