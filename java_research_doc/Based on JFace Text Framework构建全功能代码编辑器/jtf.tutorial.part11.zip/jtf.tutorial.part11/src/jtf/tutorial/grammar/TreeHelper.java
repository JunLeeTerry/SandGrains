package jtf.tutorial.grammar;

import java.util.ArrayList;
import java.util.List;

import org.antlr.runtime.CommonToken;
import org.antlr.runtime.Token;
import org.antlr.runtime.tree.CommonTree;
import org.antlr.runtime.tree.Tree;
import org.eclipse.swt.graphics.Point;

public class TreeHelper {
	/**
	 * Get all declared variables
	 */
	public static List<String> getVariables(Tree tree) {
		List<String> variables = new ArrayList<String>();
		internalGetVariables(tree, variables);
		return variables;
	}
	
	/**
	 * Get variables from syntax tree, internal used only
	 */
	private static void internalGetVariables(Tree tree, List<String> variables) {
		// visit first child
		int count = tree.getChildCount();
		if(count > 0)
			internalGetVariables(tree.getChild(0), variables);
		
		// visit itself
		if(tree.getType() == IExprTokens.EQ) {
			Token token = ((CommonTree)tree.getChild(0)).getToken();
			String var = token.getText();
			if(!variables.contains(var))
				variables.add(var);
		}
		
		// visit other children
		for(int i = 1; i < count; i++)
			internalGetVariables(tree.getChild(i), variables);
	}
	
	/**
	 * Get source code range of declaration of given variable
	 */
	public static Point getVariableDeclaration(Tree tree, String var) {
		Point ret = null;
		
		// visit first child
		int count = tree.getChildCount();
		if(count > 0)
			ret = getVariableDeclaration(tree.getChild(0), var);
		if(ret != null)
			return ret;
		
		// visit itself
		if(tree.getType() == IExprTokens.EQ) {
			CommonToken token = (CommonToken)((CommonTree)tree.getChild(0)).getToken();
			String text = token.getText();
			if(text.equals(var))
				ret = getTreeRange(tree);
			if(ret != null)
				return ret;
		}
		
		// visit other children
		for(int i = 1; i < count; i++) {
			ret = getVariableDeclaration(tree.getChild(i), var);
			if(ret != null)
				return ret;
		}
		
		return null;
	}
	
	/**
	 * Get source range of a tree node
	 */
	private static Point getTreeRange(Tree tree) {
		// get left-most child
		CommonTree left = (CommonTree)tree;
		while(left.getChildCount() > 0)
			left = (CommonTree)left.getChild(0);
		
		// get right-most child
		CommonTree right = (CommonTree)tree;
		while(right.getChildCount() > 1)
			right = (CommonTree)right.getChild(right.getChildCount() - 1);
		
		// get range
		return new Point(((CommonToken)left.getToken()).getStartIndex(), ((CommonToken)right.getToken()).getStopIndex() - ((CommonToken)left.getToken()).getStartIndex() + 1);
	}
}
