package jtf.tutorial.ui;

import jtf.tutorial.annotationhover.ExprAnnotationHover;
import jtf.tutorial.contentassistant.ExprContentAssistProcessor;
import jtf.tutorial.doubleclick.ExprDoubleClickStrategy;
import jtf.tutorial.hyperlink.ExprHyperlinkDetector;
import jtf.tutorial.quickassistant.ExprQuickAssistProcessor;
import jtf.tutorial.syntaxhighlight.ExprTokenScanner;
import jtf.tutorial.textfolding.ExprReconcilingStrategy;
import jtf.tutorial.textformatting.ExprFormattingStrategy;
import jtf.tutorial.texthover.ExprTextHover;
import jtf.tutorial.tripleclick.ExprTripleClickStrategy;
import jtf.tutorial.tripleclick.ITextTripleClickStrategy;

import org.eclipse.jface.text.DefaultInformationControl;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.ITextDoubleClickStrategy;
import org.eclipse.jface.text.ITextHover;
import org.eclipse.jface.text.contentassist.ContentAssistant;
import org.eclipse.jface.text.contentassist.IContentAssistProcessor;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.jface.text.formatter.ContentFormatter;
import org.eclipse.jface.text.formatter.IContentFormatter;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;
import org.eclipse.jface.text.presentation.IPresentationReconciler;
import org.eclipse.jface.text.presentation.PresentationReconciler;
import org.eclipse.jface.text.quickassist.IQuickAssistAssistant;
import org.eclipse.jface.text.quickassist.IQuickAssistProcessor;
import org.eclipse.jface.text.quickassist.QuickAssistAssistant;
import org.eclipse.jface.text.reconciler.IReconciler;
import org.eclipse.jface.text.reconciler.MonoReconciler;
import org.eclipse.jface.text.rules.DefaultDamagerRepairer;
import org.eclipse.jface.text.rules.ITokenScanner;
import org.eclipse.jface.text.source.IAnnotationHover;
import org.eclipse.jface.text.source.ISourceViewer;
import org.eclipse.jface.text.source.SourceViewerConfiguration;
import org.eclipse.swt.widgets.Shell;

public class ExprConfiguation extends SourceViewerConfiguration implements IExprViewerConfiguration {
	private ITokenScanner tokenScanner;
	
	@Override
	public IPresentationReconciler getPresentationReconciler(ISourceViewer sourceViewer) 
	{
		PresentationReconciler reconciler = new PresentationReconciler();
		
		DefaultDamagerRepairer dr = new DefaultDamagerRepairer(getTokenScanner());
		reconciler.setDamager(dr, IDocument.DEFAULT_CONTENT_TYPE);
		reconciler.setRepairer(dr, IDocument.DEFAULT_CONTENT_TYPE);
		
		return reconciler;
	}

	/**
	 * Get token scanner
	 */
	protected ITokenScanner getTokenScanner() 
	{
		if(tokenScanner == null)
			tokenScanner = new ExprTokenScanner();
		return tokenScanner;
	}
	
	@Override
	public ITextDoubleClickStrategy getDoubleClickStrategy(
	        ISourceViewer sourceViewer, String contentType) {
	    return new ExprDoubleClickStrategy();
	}

	public ITextTripleClickStrategy getTripleClickStrategy(ISourceViewer viewer, String contentType) {
		return new ExprTripleClickStrategy();
    }
	
	@Override
	public IContentAssistant getContentAssistant(ISourceViewer sourceViewer) {
        ContentAssistant assistant = new ContentAssistant();
        assistant.setInformationControlCreator(new IInformationControlCreator() {
        	public IInformationControl createInformationControl(Shell parent)
        	{
        		DefaultInformationControl control = new DefaultInformationControl(parent);
        		return control;
        	}
        });

        // add assist processor
        IContentAssistProcessor processor = new ExprContentAssistProcessor();
        assistant.setContentAssistProcessor(processor, IDocument.DEFAULT_CONTENT_TYPE);
        
        return assistant;
	}
	
	@Override
	public ITextHover getTextHover(ISourceViewer sourceViewer, String contentType) {
		return new ExprTextHover(sourceViewer);
	}
	
	@Override
	public IAnnotationHover getAnnotationHover(ISourceViewer sourceViewer) {
		return new ExprAnnotationHover();
	}
	
	@Override
	public IQuickAssistAssistant getQuickAssistAssistant(ISourceViewer sourceViewer) {
		IQuickAssistAssistant assistant = new QuickAssistAssistant();
        assistant.setInformationControlCreator(new IInformationControlCreator() {
        	public IInformationControl createInformationControl(Shell parent)
        	{
        		DefaultInformationControl control = new DefaultInformationControl(parent);
        		return control;
        	}
        });
        
        // add processor
        IQuickAssistProcessor processor = new ExprQuickAssistProcessor();
        assistant.setQuickAssistProcessor(processor);
		
		return assistant;
	}
	
	@Override
	public IHyperlinkDetector[] getHyperlinkDetectors(ISourceViewer sourceViewer) {
		return new IHyperlinkDetector[] {
				new ExprHyperlinkDetector()
		};
	}
	
	@Override
	public IContentFormatter getContentFormatter(ISourceViewer sourceViewer) {
		ContentFormatter formatter = new ContentFormatter();
		formatter.setFormattingStrategy(new ExprFormattingStrategy(), IDocument.DEFAULT_CONTENT_TYPE);
		return formatter;
	}
	
	@Override
	public IReconciler getReconciler(ISourceViewer sourceViewer) {
		return new MonoReconciler(new ExprReconcilingStrategy((ExprViewer)sourceViewer), false);
	}
}
