package jtf.tutorial.template;

import jtf.tutorial.Activator;

import org.eclipse.ui.IWorkbenchPreferencePage;
import org.eclipse.ui.texteditor.templates.TemplatePreferencePage;

public class ExprTemplatePreferencePage extends TemplatePreferencePage implements IWorkbenchPreferencePage {
	public ExprTemplatePreferencePage() {
		setPreferenceStore(Activator.getDefault().getPreferenceStore());
		setTemplateStore(Activator.getDefault().getTemplateStore());
		setContextTypeRegistry(Activator.getDefault().getContextTypeRegistry());
	}

	protected boolean isShowFormatterSetting() {
		return false;
	}

	public boolean performOk() {
		boolean ok = super.performOk();
		Activator.getDefault().savePluginPreferences();
		return ok;
	}
}
