package jtf.tutorial.texthover;

import jtf.tutorial.grammar.IExprTokens;
import jtf.tutorial.grammar.SharedParser;
import jtf.tutorial.grammar.TokenList;
import jtf.tutorial.grammar.TokenManager;
import jtf.tutorial.grammar.TreeManager;

import org.antlr.runtime.Token;
import org.eclipse.jface.text.DefaultTextHover;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.source.ISourceViewer;

public class ExprTextHover extends DefaultTextHover {
	public ExprTextHover(ISourceViewer sourceViewer) {
		super(sourceViewer);
	}

	@Override
	public IRegion getHoverRegion(ITextViewer textViewer, int offset) {
		return new Region(offset, 1);
	}
	
	@Override
	public String getHoverInfo(ITextViewer textViewer, IRegion hoverRegion) {
		// query super first
		String info = super.getHoverInfo(textViewer, hoverRegion);

		// if null, use our logic
		if(info == null) {
			// get document
			IDocument doc = textViewer.getDocument();
			
			// get token list
			TokenList list = TokenManager.getTokenList(doc);
			
			// get token
			Token token = list.getToken(hoverRegion.getOffset());
			if(token == null)
				return null;
			
			// if token is variable, get variable value
			if(token.getType() == IExprTokens.ID) {
				// parse
				TreeManager.getTree(doc);
				return String.valueOf(SharedParser.getVariableValue(token.getText()));
			} else
				return null;
		} else
			return info;
	}
}
