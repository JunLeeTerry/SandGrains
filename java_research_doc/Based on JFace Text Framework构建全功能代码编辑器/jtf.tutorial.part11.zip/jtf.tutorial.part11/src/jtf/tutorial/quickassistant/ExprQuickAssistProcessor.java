package jtf.tutorial.quickassistant;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import jtf.tutorial.grammar.TreeHelper;
import jtf.tutorial.grammar.TreeManager;

import org.antlr.runtime.tree.Tree;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.Position;
import org.eclipse.jface.text.contentassist.CompletionProposal;
import org.eclipse.jface.text.contentassist.ICompletionProposal;
import org.eclipse.jface.text.quickassist.IQuickAssistInvocationContext;
import org.eclipse.jface.text.quickassist.IQuickAssistProcessor;
import org.eclipse.jface.text.source.Annotation;
import org.eclipse.jface.text.source.IAnnotationModel;
import org.eclipse.jface.text.source.ISourceViewer;

public class ExprQuickAssistProcessor implements IQuickAssistProcessor {
	public boolean canAssist(IQuickAssistInvocationContext invocationContext) {
		return true;
	}

	public boolean canFix(Annotation annotation) {
		return annotation.getType().equals("jtf.tutorial.annotation.undeclared.variable");
	}

	public ICompletionProposal[] computeQuickAssistProposals(IQuickAssistInvocationContext invocationContext) {
		// get viewer
		ISourceViewer viewer = invocationContext.getSourceViewer();
		
		// get annotation
		Annotation anno = getAnnotation(viewer, invocationContext.getOffset());
		if(anno == null || !canFix(anno))
			return null;
		
		// get doc
		IDocument doc = viewer.getDocument();
		
		// get tree
		Tree tree = TreeManager.getTree(doc);
		if(tree == null)
			return null;
		
		// get all declared variables
		List<String> variables = TreeHelper.getVariables(tree);
		
		// create proposals
		Position pos = viewer.getAnnotationModel().getPosition(anno);
		List<ICompletionProposal> proposals = new ArrayList<ICompletionProposal>();
		for(String var : variables) {
			proposals.add(new CompletionProposal(var, pos.getOffset(), pos.getLength(), var.length(), null, var, null, "Add your info here"));
		}
		return proposals.toArray(new ICompletionProposal[proposals.size()]);
	}

	public String getErrorMessage() {
		return null;
	}
	
	/**
	 * Get annotation by character offset
	 */
	private Annotation getAnnotation(ISourceViewer viewer, int offset) {
		IAnnotationModel model = viewer.getAnnotationModel();
		Iterator i = model.getAnnotationIterator();
		while(i.hasNext()) {
			Annotation anno = (Annotation)i.next();
			Position pos = model.getPosition(anno);
			if(pos.overlapsWith(offset, 0) || pos.overlapsWith(offset - 1, 0))
				return anno;
		}
		return null;
	}
}
