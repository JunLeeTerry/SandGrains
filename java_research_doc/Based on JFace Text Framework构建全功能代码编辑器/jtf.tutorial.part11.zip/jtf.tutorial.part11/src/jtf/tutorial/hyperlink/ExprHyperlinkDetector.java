package jtf.tutorial.hyperlink;

import jtf.tutorial.grammar.IExprTokens;
import jtf.tutorial.grammar.TokenList;
import jtf.tutorial.grammar.TokenManager;

import org.antlr.runtime.CommonToken;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.Region;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.jface.text.hyperlink.IHyperlinkDetector;

public class ExprHyperlinkDetector implements IHyperlinkDetector {
	public IHyperlink[] detectHyperlinks(ITextViewer textViewer, IRegion region, boolean canShowMultipleHyperlinks) {
		// get doc
		IDocument doc = textViewer.getDocument();
		
		// get token list
		TokenList list = TokenManager.getTokenList(doc);
		
		// get token
		CommonToken token = list.getToken(region.getOffset());
		
		// if token is a ID, ok
		if(token.getType() == IExprTokens.ID) {
			return new IHyperlink[] {
					new VariableHyperlink(new Region(token.getStartIndex(), token.getStopIndex() - token.getStartIndex() + 1), token.getText(), textViewer)
			};
		} else
			return null;
	}
}
