package jtf.tutorial.hyperlink;

import jtf.tutorial.grammar.TreeHelper;
import jtf.tutorial.grammar.TreeManager;

import org.antlr.runtime.tree.Tree;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IRegion;
import org.eclipse.jface.text.ITextViewer;
import org.eclipse.jface.text.hyperlink.IHyperlink;
import org.eclipse.swt.graphics.Point;

public class VariableHyperlink implements IHyperlink {
	private IRegion region;
	private String variable;
	private ITextViewer viewer;
	
	public VariableHyperlink(IRegion region, String variable, ITextViewer viewer) {
		this.region = region;
		this.variable = variable;
		this.viewer = viewer;
	}
	
	public IRegion getHyperlinkRegion() {
		return region;
	}

	public String getHyperlinkText() {
		return null;
	}

	public String getTypeLabel() {
		return null;
	}

	public void open() {
		// get doc
		IDocument doc = viewer.getDocument();
		
		// get tree
		Tree tree = TreeManager.getTree(doc);
		
		// get variable declaration range
		Point range = TreeHelper.getVariableDeclaration(tree, variable);
		
		// select text
		if(range != null) {
			viewer.revealRange(range.x, range.y);
			viewer.setSelectedRange(range.x, range.y);
		}
	}
}
