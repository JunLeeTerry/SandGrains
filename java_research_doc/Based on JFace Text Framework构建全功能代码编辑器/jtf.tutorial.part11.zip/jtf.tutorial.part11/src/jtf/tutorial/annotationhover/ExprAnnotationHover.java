package jtf.tutorial.annotationhover;

import org.eclipse.jface.text.source.DefaultAnnotationHover;

public class ExprAnnotationHover extends DefaultAnnotationHover {

}
