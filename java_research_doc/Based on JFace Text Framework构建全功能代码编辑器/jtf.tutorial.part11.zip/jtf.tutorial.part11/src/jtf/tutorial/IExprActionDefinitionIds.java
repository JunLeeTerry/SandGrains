package jtf.tutorial;

public interface IExprActionDefinitionIds {
	public static final String FORMAT = "jtf.tutorial.command.format";
}
