package jtf.tutorial.textformatting;

import java.util.List;

import jtf.tutorial.grammar.IExprTokens;
import jtf.tutorial.grammar.SharedParser;

import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.Token;
import org.eclipse.jface.text.formatter.IFormattingStrategy;

public class ExprFormattingStrategy implements IFormattingStrategy {
	public String format(String content, boolean isLineStart, String indentation, int[] positions) {
		CommonTokenStream stream = SharedParser.getTokenStream(content);
		List<Token> tokens = stream.getTokens();
		StringBuffer buf = new StringBuffer();
		boolean start = true;
		for(Token token : tokens) {
			if(token.getType() != IExprTokens.WS) {
				if(token.getType() != IExprTokens.COMMA && !start)
					buf.append(' ');
				buf.append(token.getText());
				start = false;
				if(token.getType() == IExprTokens.COMMA) {
					buf.append('\n');
					start = true;
				}
			}
		}
		if(buf.charAt(0) == ' ')
			buf.deleteCharAt(0);
		return buf.toString();
	}

	public void formatterStarts(String initialIndentation) {
	}

	public void formatterStops() {
	}
}
